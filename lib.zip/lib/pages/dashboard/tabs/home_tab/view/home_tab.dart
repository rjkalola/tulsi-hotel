import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:tulsi_hotel/pages/dashboard/view/widgets/dashboard_item_box.dart';
import 'package:tulsi_hotel/widgets/custom_views/no_internet_widgets.dart';
import 'package:tulsi_hotel/widgets/progressbar/CustomProgressbar.dart';
import 'package:tulsi_hotel/widgets/text/PrimaryTextView.dart';

import '../../../../../res/colors.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> with AutomaticKeepAliveClientMixin {
  int selectedActionButtonPagerPosition = 0;

  @override
  void initState() {
    // showProgress();
    // setHeaderActionButtons();
    // userInfo = Get.find<AppStorage>().getUserInfo();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      // backgroundColor: const Color(0xfff4f5f7),
      body: false
          ? NoInternetWidget(
              onPressed: () {
                // controller.isInternetNotAvailable.value = false;
                // controller.getDashboardUserPermissionsApi(true);
              },
            )
          : ModalProgressHUD(
              inAsyncCall: false,
              opacity: 0,
              progressIndicator: const CustomProgressbar(),
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 20,
                      ),
                      PrimaryTextView(
                        'for_today'.tr,
                        fontWeight: FontWeight.w600,
                        fontSize: 17,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      DashboardItemBox(
                        title: 'order_a_lunch'.tr,
                        time: 'lunch_time'.tr,
                      ),
                      SizedBox(
                        height: 14,
                      ),
                      DashboardItemBox(
                        title: 'order_a_dinner'.tr,
                        time: 'dinner_time'.tr,
                      ),


                      SizedBox(
                        height: 20,
                      ),
                      PrimaryTextView(
                        'for_tomorrow'.tr,
                        fontWeight: FontWeight.w600,
                        fontSize: 17,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      DashboardItemBox(
                        title: 'order_a_lunch'.tr,
                        time: 'lunch_time'.tr,
                      ),
                      SizedBox(
                        height: 14,
                      ),
                      DashboardItemBox(
                        title: 'order_a_dinner'.tr,
                        time: 'dinner_time'.tr,
                      ),
                      SizedBox(height: 20,)
                    ],
                  ),
                ),
              ),
            ),

      /* body: Visibility(
          visible: controller.isMainViewVisible.value,
          child: Column(children: [
            HeaderUserDetailsView(),
            SizedBox(
              height: 12,
            ),
            DashboardGridView()
          ]),
        ),*/
    );
  }

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    // controller.dispose();
    super.dispose();
  }
}
