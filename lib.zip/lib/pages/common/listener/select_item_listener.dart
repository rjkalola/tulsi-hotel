abstract class SelectItemListener {
  void onSelectItem(int position, int id, String name, String action);
}
