abstract class SelectDateListener {
  void onSelectDate(DateTime date,String dialogIdentifier);
}

