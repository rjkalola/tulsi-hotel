import 'package:dio/dio.dart' as multi;

import '../../../../web_services/api_constants.dart';
import '../../../../web_services/network/api_request.dart';
import '../../../../web_services/response/response_model.dart';

class DashboardRepository {

}
