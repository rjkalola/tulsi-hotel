class BaseResponse {
  String? message, statusCode;
  bool? isSuccess;

  BaseResponse({this.isSuccess, this.message, this.statusCode});

  BaseResponse.fromJson(Map<String, dynamic> json) {
    isSuccess = json['IsSuccess'];
    message = json['Message'];
    statusCode = json['statusCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['IsSuccess'] = isSuccess;
    data['Message'] = message;
    data['statusCode'] = statusCode;
    return data;
  }
}
