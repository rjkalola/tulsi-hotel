abstract class DialogButtonClickListener {
  void onPositiveButtonClicked(String dialogIdentifier);
  void onNegativeButtonClicked(String dialogIdentifier);
  void onOtherButtonClicked(String dialogIdentifier);
}

