class AppRoutes {
  static const String splashScreen = '/';
  static const String loginScreen = '/login_screen';
  static const String otpVerificationScreen = '/otp_verification_screen';
  static const String dashboardScreen = '/dashboard_screen';
}
